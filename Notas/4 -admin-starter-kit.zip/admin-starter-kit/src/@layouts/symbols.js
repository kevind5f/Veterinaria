export const injectionKeyIsVerticalNavHovered = Symbol('isVerticalNavHovered')
