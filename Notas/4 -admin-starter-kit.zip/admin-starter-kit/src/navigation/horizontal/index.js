export default [
  {
    title: 'Home',
    to: { name: 'root' },
    icon: { icon: 'ri-home-smile-2-line' },
  },
  {
    title: 'Second page',
    to: { name: 'second-page' },
    icon: { icon: 'ri-file-text-line' },
  },
]
